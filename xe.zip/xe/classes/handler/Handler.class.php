<?php
/* Copyright (C) XEHub <https://www.xehub.io> */

/**
 * An abstract class of (*)Handler 
 *
 * @author XEHub (developers@xpressengine.com)
 */
class Handler
{

}
/* End of file Handler.class.php */
/* Location: ./classes/handler/Handler.class.php */
