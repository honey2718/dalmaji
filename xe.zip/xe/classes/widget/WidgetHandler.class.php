<?php
/* Copyright (C) XEHub <https://www.xehub.io> */

/**
 * @class WidgetHandler
 * @author XEHub (developers@xpressengine.com)
 * @brief Handler class for widget execution
 * @remark it is empty for now, it would be removed in the future
 */
class WidgetHandler
{

	var $widget_path = '';

}
/* End of file WidgetHandler.class.php */
/* Location: ./classes/widget/WidgetHandler.class.php */
